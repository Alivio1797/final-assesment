function factorial(n) {

}

// Jangan hapus kode di bawah ini!
export default factorial;
