// index.test.js
import test from 'node:test';
import assert from 'node:assert';
import { sum } from './index.js'; // Import fungsi sum dari index.js

//Menjumlahkan dua bilangan positif
test('Menjumlahkan dua bilangan positif', () => {
  const result = sum(2, 6);
  assert.strictEqual(result, 8, '2 + 6 harusnya 8');
});

//Menjumlahkan bilangan positif dan negatif
test('Menjumlahkan bilangan positif dan negatif', () => {
  const result = sum(8, -3);
  assert.strictEqual(result, 5, '8 + (-3) harusnya 2');
});

//Menjumlahkan dua bilangan negatif
test('Menjumlahkan dua bilangan negatif', () => {
  const result = sum(-8, -6);
  assert.strictEqual(result, -14, '-8 + (-6) harusnya -14');
});

//Menjumlahkan bilangan dengan nol
test('Menjumlahkan bilangan dengan nol', () => {
  const result = sum(7, 1);
  assert.strictEqual(result, 8, '7 + 1 harusnya 8');
});

//Menjumlahkan dua bilangan desimal
test('Menjumlahkan dua bilangan desimal', () => {
  const result = sum(2.5, 2.5);
  assert.strictEqual(result, 5, '2.5 + 2.5 harusnya 5');
});
